# ReceiptGG — Budget Gaming Guides

A budget PC/phone gaming site with a live, auto-updating price table pulled
from Star Tech (Bangladesh) once a day — no manual updates needed.

## How it's put together

- `index.html` — the site itself. Reads `data/prices.json` in the browser
  and renders a live price table. No server needed to host it.
- `scripts/scrape_prices.py` — a Python script that fetches current prices
  from Star Tech and saves them to `data/prices.json`.
- `.github/workflows/scrape.yml` — tells GitHub to run that script
  automatically, once a day, for free, and save the updated prices back
  into the project.

## Setup (one-time, ~15 minutes)

1. **Create a free GitHub account** at github.com if you don't have one.

2. **Create a new repository**
   - Click the "+" in the top right → "New repository"
   - Name it something like `receiptgg`
   - Keep it Public (needed for free GitHub Pages + Actions)
   - Click "Create repository"

3. **Upload these files**
   - On the repo page, click "Add file" → "Upload files"
   - Drag in everything from this project, keeping the folder structure
     (`.github/workflows/scrape.yml`, `scripts/scrape_prices.py`,
     `scripts/requirements.txt`, `data/prices.json`, `index.html`)
   - Commit the upload

4. **Turn on GitHub Pages** (this makes the site live)
   - Go to Settings → Pages
   - Under "Source", choose the `main` branch, root folder
   - Save — your site will be live at `https://yourusername.github.io/receiptgg/`
     within a minute or two

5. **Run the scraper for the first time**
   - Go to the "Actions" tab on your repo
   - Click "Update prices" in the left sidebar
   - Click "Run workflow" → "Run workflow" (this triggers it manually,
     you don't have to wait for the daily schedule)
   - After it finishes (~30 seconds), `data/prices.json` will be updated
     with real prices, and your live site will show them

From here, it re-runs automatically every day — you don't need to do
anything. If you ever change your GitHub username or repo name, double
check the Pages URL still matches.

## If prices stop showing up

The most likely cause is Star Tech changing their page layout, which
breaks the CSS selectors in `scripts/scrape_prices.py`. To fix:

1. Open a category page (e.g. the graphics card page) in your browser
2. Right-click a product → "Inspect"
3. Compare the HTML structure to the selectors in `scrape_category()`
   (look for `.product-thumb`, `.caption h4 a`, `.price-new`)
4. Update the selectors to match, commit, and re-run the workflow

## Adding more categories or retailers

Add an entry to the `CATEGORIES` dict in `scripts/scrape_prices.py` with
the category name and Star Tech URL. For a different retailer entirely,
you'll likely need a new function since the page structure will differ.

## Honest limitations

- This is a real scraper hitting a real website — it can break, get
  rate-limited, or be against the retailer's Terms of Service. Keep the
  request delay in the script, and don't scrape more often than daily.
- Only the first page of each category is scraped (up to 30 items) to
  keep things simple and fast.
